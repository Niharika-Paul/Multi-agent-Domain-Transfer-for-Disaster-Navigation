import random
import math

from agent_snn_v3 import SNNAgent
from hybrid_spatial_index import _haversine_m

# =====================================================
# METRICS
# =====================================================

def compute_metrics(graph, path, goal_node, max_steps=200):
    if not path:
        return {
            "success": 0,
            "length": float("inf"),
            "time": float("inf"),
            "hazard": float("inf"),
        }

    if len(path) > max_steps:
        path = path[:max_steps]

    success = 1 if path[-1] == goal_node else 0

    length = graph.path_distance_m(path)
    time   = graph.path_travel_time_s(path)
    hazard = sum(graph.get_node_damage(n) for n in path)

    return {
        "success": success,
        "length": length,
        "time": time,
        "hazard": hazard,
    }


# =====================================================
# DISASTER HELPERS
# =====================================================

def _random_shift(graph, node_id):
    base = graph._nodes[node_id]
    dlat = random.uniform(-0.005, 0.005)
    dlon = random.uniform(-0.005, 0.005)
    return (base['lat'] + dlat, base['lon'] + dlon)


def _dynamic_disaster(graph, centre):
    graph.reset_disaster()
    graph.apply_disaster(
        disaster_type="aftershock",
        centre=centre,
        radius_m=random.randint(500, 1500),
        severity=random.uniform(0.3, 0.8),
    )


# =====================================================
# BASELINES (STATIC)
# =====================================================

def run_astar(graph, start, goal, max_steps=200):
    path = graph.shortest_path_astar(start, goal, avoid_damaged=False)
    return path[:max_steps] if path else None


def run_dijkstra_hazard(graph, start, goal, alpha=10, max_steps=200):
    import heapq

    pq = [(0, start)]
    dist = {start: 0}
    parent = {}

    while pq:
        cost, node = heapq.heappop(pq)

        if node == goal:
            break

        for neigh, edge in graph._adj[node]:
            edge_len = edge['length']
            damage = graph.get_node_damage(neigh)
            new_cost = cost + edge_len + alpha * damage

            if neigh not in dist or new_cost < dist[neigh]:
                dist[neigh] = new_cost
                parent[neigh] = node
                heapq.heappush(pq, (new_cost, neigh))

    if goal not in parent:
        return None

    path = []
    cur = goal
    while cur != start:
        path.append(cur)
        cur = parent[cur]
    path.append(start)

    return path[::-1][:max_steps]


def run_greedy(graph, start, goal, max_steps=200):
    path = [start]
    current = start
    visited = set()

    for _ in range(max_steps):
        if current == goal:
            break

        visited.add(current)

        neighbors = graph._adj.get(current, [])
        if not neighbors:
            break

        best = None
        best_dist = float("inf")

        for neigh, _ in neighbors:
            if neigh in visited:
                continue

            d = _haversine_m(
                graph._nodes[neigh]["lat"],
                graph._nodes[neigh]["lon"],
                graph._nodes[goal]["lat"],
                graph._nodes[goal]["lon"],
            )

            if d < best_dist:
                best_dist = d
                best = neigh

        if best is None:
            break

        path.append(best)
        current = best

    return path


# =====================================================
# SNN (DYNAMIC DISASTER)
# =====================================================

def run_snn(graph, start, goal, steps=200):
    agent = SNNAgent(graph, start, goal)

    agent.shared_memory = {
        "blocked_nodes": set(),
        "danger_nodes": {},
        "pheromones": {},
    }

    for t in range(steps):
        agent.step()

        if agent.reached_goal or not agent.alive:
            break

    return agent.path


# =====================================================
# MAIN EVALUATION
# =====================================================

def evaluate_all(load_graph_fn, start, goal, n_runs=20, steps=200, seed=42):

    results = {
        "astar": [],
        "dijkstra": [],
        "greedy": [],
        "snn": []
    }

    for i in range(n_runs):
        random.seed(seed + i)

        # ---------- A* ----------
        graph = load_graph_fn()
        path = run_astar(graph, start, goal, steps)
        results["astar"].append(
            compute_metrics(graph, path, goal, steps)
        )

        # ---------- DIJKSTRA ----------
        graph = load_graph_fn()
        path = run_dijkstra_hazard(graph, start, goal, max_steps=steps)
        results["dijkstra"].append(
            compute_metrics(graph, path, goal, steps)
        )

        # ---------- GREEDY ----------
        graph = load_graph_fn()
        path = run_greedy(graph, start, goal, steps)
        results["greedy"].append(
            compute_metrics(graph, path, goal, steps)
        )

        # ---------- SNN (DYNAMIC) ----------
        graph = load_graph_fn()
        path = run_snn(graph, start, goal, steps)
        results["snn"].append(
            compute_metrics(graph, path, goal, steps)
        )

    return summarize(results)


# =====================================================
# SUMMARY
# =====================================================

def summarize(results):
    summary = {}

    for method, runs in results.items():
        n = len(runs)

        summary[method] = {
            "success_rate": sum(r["success"] for r in runs) / n,
            "avg_length": sum(r["length"] for r in runs) / n,
            "avg_time": sum(r["time"] for r in runs) / n,
            "avg_hazard": sum(r["hazard"] for r in runs) / n,
        }

    return summary


# =====================================================
# PRINT
# =====================================================

def print_results(summary):
    print("\n===== COMPARISON RESULTS =====\n")

    for method, m in summary.items():
        print(method.upper())
        print(f"  Success rate : {m['success_rate']*100:.1f}%")
        print(f"  Avg length   : {m['avg_length']:.1f} m")
        print(f"  Avg time     : {m['avg_time']:.1f} s")
        print(f"  Avg hazard   : {m['avg_hazard']:.2f}")
        print()