import random
import json

from evaluate_algorithms_2 import evaluate_all, print_results
from test_swarm_v3_multiagents import load_fresh_graph
from hybrid_spatial_index import _haversine_m


# --------------------------------------------------
# SETTINGS
# --------------------------------------------------
SEED = 42
NUM_PAIRS = 20
RUNS_PER_PAIR = 10
STEPS = 200

random.seed(SEED)


# --------------------------------------------------
# PAIR GENERATION
# --------------------------------------------------
def generate_pairs(graph, n=20, min_dist=1000, max_dist=4000):
    pairs = []
    nodes = list(graph._nodes.keys())

    attempts = 0
    max_attempts = 10000

    while len(pairs) < n and attempts < max_attempts:
        attempts += 1

        s = random.choice(nodes)
        g = random.choice(nodes)

        if s == g:
            continue

        d = _haversine_m(
            graph._nodes[s]['lat'], graph._nodes[s]['lon'],
            graph._nodes[g]['lat'], graph._nodes[g]['lon']
        )

        if min_dist <= d <= max_dist:
            pairs.append((s, g))

    if len(pairs) < n:
        print(f"Warning: only generated {len(pairs)} pairs")

    return pairs


# --------------------------------------------------
# AGGREGATION
# --------------------------------------------------
def aggregate_results(all_results):
    final = {}

    methods = all_results[0].keys()

    for m in methods:
        success = []
        length = []
        time = []
        hazard = []

        for res in all_results:
            success.append(res[m]["success_rate"])
            length.append(res[m]["avg_length"])
            time.append(res[m]["avg_time"])
            hazard.append(res[m]["avg_hazard"])

        def mean_std(x):
            mean = sum(x) / len(x)
            var = sum((v - mean)**2 for v in x) / len(x)
            return mean, var**0.5

        final[m] = {
            "success": mean_std(success),
            "length": mean_std(length),
            "time": mean_std(time),
            "hazard": mean_std(hazard),
        }

    return final


# --------------------------------------------------
# MAIN
# --------------------------------------------------
if __name__ == "__main__":

    print("\n==============================")
    print("LOADING GRAPH")
    print("==============================")

    graph = load_fresh_graph()

    # --------------------------------------------------
    # 1. SANITY CHECK (single pair)
    # --------------------------------------------------
    print("\n==============================")
    print("SANITY CHECK (1 PAIR)")
    print("==============================")

    single_pair = generate_pairs(graph, n=1)
    start, goal = single_pair[0]

    summary = evaluate_all(
        load_graph_fn=load_fresh_graph,
        start=start,
        goal=goal,
        n_runs=20,
        steps=STEPS
    )

    print_results(summary)

    # --------------------------------------------------
    # 2. FULL EXPERIMENT
    # --------------------------------------------------
    print("\n==============================")
    print("FULL EXPERIMENT")
    print("==============================")

    pairs = generate_pairs(graph, n=NUM_PAIRS)

    all_results = []

    for i, (s, g) in enumerate(pairs):
        print(f"\n--- Pair {i+1}/{NUM_PAIRS} ---")

        res = evaluate_all(
            load_graph_fn=load_fresh_graph,
            start=s,
            goal=g,
            n_runs=RUNS_PER_PAIR,
            steps=STEPS
        )

        all_results.append(res)

    # --------------------------------------------------
    # 3. AGGREGATE RESULTS
    # --------------------------------------------------
    print("\n==============================")
    print("FINAL AGGREGATED RESULTS")
    print("==============================")

    final = aggregate_results(all_results)

    for m, v in final.items():
        print(f"\n{m.upper()}")
        print(f"Success: {v['success'][0]*100:.1f}% ± {v['success'][1]*100:.1f}")
        print(f"Length : {v['length'][0]:.1f} ± {v['length'][1]:.1f}")
        print(f"Time   : {v['time'][0]:.1f} ± {v['time'][1]:.1f}")
        print(f"Hazard : {v['hazard'][0]:.2f} ± {v['hazard'][1]:.2f}")

    # --------------------------------------------------
    # 4. SAVE RESULTS
    # --------------------------------------------------
    with open("results.json", "w") as f:
        json.dump(final, f, indent=2)

    print("\nResults saved to results_v2.json")