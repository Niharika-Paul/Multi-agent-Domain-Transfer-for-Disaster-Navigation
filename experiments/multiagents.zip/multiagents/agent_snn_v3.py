import math
import random
from collections import deque

from snn_core_v2 import SNNDecision, haversine_distance


class SNNAgent:
    """
    Three-tier memory navigation agent — v4 oscillation fixes:

    FIX-1  Taboo eviction reference-count bug
           _taboo_add used `if evicted not in self.taboo_queue` to guard removal
           from taboo_set. A node visited twice appears twice in the deque; the
           second eviction finds it absent from the queue and incorrectly removes
           it from taboo_set even though one entry remains. Fixed with an explicit
           per-node reference counter (taboo_counts dict).

    FIX-2  Stall counter measured the *candidate* next_node, not the *executed* one
           _steps_without_progress was incremented in step() before the oscillation
           handler could silently replace next_node. The counter therefore fired on
           phantom (unapplied) distances. Moved stall check into _execute_move so
           it always measures the node that was actually visited.
           The stall *correction* is stored as _stall_override and applied at the
           very top of the next step() call — avoiding any recursive _execute_move
           calls that would double-book path/taboo state.

    FIX-3  Stall escape moved agent *away* from goal
           When stalled, the handler chose max(unvisited_far, key=dist) — the node
           farthest from the goal — which is backwards. Changed to min(key=dist):
           pick the closest unvisited non-blacklisted neighbor for real progress.

    FIX-4  _blacklist_cycle_nodes over-blacklisted, trapping agents
           Old code blacklisted the full cycle window + current + prev. In sparse
           graphs this leaves no escape neighbors, causing permanent random walks.
           New rules:
             - Only blacklist the exact minimal repeating segment.
             - Never blacklist the goal node.
             - Never blacklist current_node (we still need to leave from here).
             - Validate that at least one non-blacklisted neighbor remains; if not,
               skip blacklisting and only reset taboo (safety valve).

    FIX-5  Cycle/oscillation escape was goal-blind (used random.choice)
           After blacklisting cycle nodes the escape was random among unvisited
           neighbors, ignoring direction. Changed to min(key=dist_to_goal) via the
           helper _goal_directed_choice(). Same fix applied to the oscillation
           counter escape branch.

    FIX-6  SwarmSimulation._rescue_near_goal_stuck checked stale counter
           (Documented and fixed in swarm_simulation_v3.py — threshold raised
           10→15 there, and a direct position_history proximity check added as
           counter-independent proof so rescue fires on actual observed evidence.)
    """

    def __init__(self, graph, start_node, goal_node):
        self.graph        = graph
        self.current_node = start_node
        self.goal_node    = goal_node

        self.snn = SNNDecision()

        self.path         = [start_node]
        self.alive        = True
        self.reached_goal = False
        self.prev_node    = None
        self.visited      = set([start_node])
        self.visit_counts = {start_node: 1}
        self.shared_memory = None
        self.local_memory  = {"danger_nodes": {}}

        # Tier 1: short-term taboo
        self.taboo_set    = set()
        self.taboo_queue  = deque()
        self.taboo_counts = {}          # FIX-1: reference counter
        self.TABOO_SIZE      = 6
        self.TABOO_SIZE_NEAR = 4

        # Tier 2: permanent blacklist
        self.blacklist = set()

        # Tier 3: cycle detection
        self.position_history = deque(maxlen=30)
        self.CYCLE_DETECT_LEN = 10

        # Oscillation counter
        self.oscillation_counter = 0
        self.OSCILLATION_LIMIT   = 6

        # Progress tracking (FIX-2: stall check lives in _execute_move)
        self._last_dist_to_goal       = None
        self._moving_away_counter     = 0
        self._steps_without_progress  = 0
        self.MAX_STEPS_WITHOUT_PROGRESS = 10
        self._stall_override          = None   # FIX-2: corrective node for next step

    # ------------------------------------------------------------------ #
    # Memory helpers
    # ------------------------------------------------------------------ #

    def _taboo_add(self, node):
        """FIX-1: Reference-counted taboo — evict from set only at refcount 0."""
        near = self._near_goal()
        size = self.TABOO_SIZE_NEAR if near else self.TABOO_SIZE

        self.taboo_queue.append(node)
        self.taboo_set.add(node)
        self.taboo_counts[node] = self.taboo_counts.get(node, 0) + 1

        while len(self.taboo_queue) > size:
            evicted = self.taboo_queue.popleft()
            self.taboo_counts[evicted] -= 1
            if self.taboo_counts[evicted] <= 0:
                self.taboo_set.discard(evicted)
                del self.taboo_counts[evicted]

    def _taboo_reset(self):
        self.taboo_set.clear()
        self.taboo_queue.clear()
        self.taboo_counts.clear()

    def _blacklist_cycle_nodes(self, cycle_len=2):
        """
        FIX-4: Blacklist only the minimal repeating segment.
        Validate escape exists; skip blacklisting if agent would be trapped.
        """
        hist = list(self.position_history)
        cycle_nodes = set(hist[-cycle_len:]) if cycle_len <= len(hist) else set(hist)

        # Never blacklist the goal or the current position
        cycle_nodes.discard(self.goal_node)
        cycle_nodes.discard(self.current_node)

        neighbors = [nid for nid, _ in self.graph._adj.get(self.current_node, [])]
        tentative_bl = self.blacklist | cycle_nodes
        if any(n not in tentative_bl for n in neighbors):
            self.blacklist = tentative_bl
        # else: don't blacklist — only reset taboo so agent can still move

        self._taboo_reset()

    def _detect_cycle(self):
        """Return (True, cycle_len) if recent history contains a repeated cycle."""
        hist = list(self.position_history)
        n    = len(hist)
        for cycle_len in range(2, self.CYCLE_DETECT_LEN + 1):
            if n < cycle_len * 2:
                continue
            if hist[-cycle_len:] == hist[-(cycle_len * 2):-cycle_len]:
                return True, cycle_len
        return False, 0

    def _near_goal(self):
        try:
            d = haversine_distance(
                self.graph._nodes[self.current_node]['lat'],
                self.graph._nodes[self.current_node]['lon'],
                self.graph._nodes[self.goal_node]['lat'],
                self.graph._nodes[self.goal_node]['lon'],
            )
            return d < 100
        except Exception:
            return False

    def _goal_directed_choice(self, candidates):
        """FIX-5: Choose the candidate node closest to the goal."""
        goal_data = self.graph._nodes[self.goal_node]
        return min(
            candidates,
            key=lambda n: haversine_distance(
                self.graph._nodes[n]['lat'], self.graph._nodes[n]['lon'],
                goal_data['lat'], goal_data['lon']
            )
        )

    # ------------------------------------------------------------------ #
    # Graph
    # ------------------------------------------------------------------ #

    def get_neighbors(self):
        return [nid for nid, _ in self.graph._adj.get(self.current_node, [])]

    # ------------------------------------------------------------------ #
    # Features
    # ------------------------------------------------------------------ #

    def build_features(self, neighbors):
        features     = []
        current_data = self.graph._nodes[self.current_node]
        goal_data    = self.graph._nodes[self.goal_node]
        current_dist = haversine_distance(
            current_data['lat'], current_data['lon'],
            goal_data['lat'],   goal_data['lon']
        )

        ph = {}
        if self.shared_memory:
            ph = self.shared_memory.get("pheromones", {})

        for nid in neighbors:
            node_data = self.graph._nodes[nid]
            dist = haversine_distance(
                node_data['lat'], node_data['lon'],
                goal_data['lat'], goal_data['lon']
            )

            hazard = self.graph.get_node_damage(nid)
            if nid in self.local_memory["danger_nodes"]:
                hazard = min(1.0, hazard + 0.3 * self.local_memory["danger_nodes"][nid])
            if self.shared_memory and nid in self.shared_memory["blocked_nodes"]:
                hazard = max(hazard, 0.95)

            count           = self.visit_counts.get(nid, 0)
            visited_penalty = math.log1p(count)
            if nid in list(self.path)[-5:]:
                visited_penalty += 1.0

            is_prev_node  = 1.0 if nid == self.prev_node else 0.0
            is_new        = 1.0 if nid not in self.visited else 0.0
            progress      = max(0.0, current_dist - dist)
            taboo_penalty = 1.0 if nid in self.taboo_set else 0.0
            bl_penalty    = 1.0 if nid in self.blacklist else 0.0

            two_hop_goal = 0.0
            if nid != self.goal_node:
                if self.goal_node in [n for n, _ in self.graph._adj.get(nid, [])]:
                    two_hop_goal = 1.0

            pheromone = ph.get(nid, 0.0)

            features.append({
                "node":         nid,
                "dist":         dist,
                "hazard":       hazard,
                "visited":      visited_penalty,
                "progress":     progress,
                "is_prev_node": is_prev_node,
                "is_new":       is_new,
                "taboo":        taboo_penalty,
                "blacklist":    bl_penalty,
                "two_hop_goal": two_hop_goal,
                "pheromone":    pheromone,
                "node_data":    node_data,
            })

        return features

    # ------------------------------------------------------------------ #
    # Step
    # ------------------------------------------------------------------ #

    def step(self):
        if not self.alive or self.reached_goal:
            return

        neighbors = self.get_neighbors()
        if not neighbors:
            self.alive = False
            return

        current_pos = self.graph._nodes[self.current_node]
        goal_pos    = self.graph._nodes[self.goal_node]

        # FIX-2: consume stall override from previous step's _execute_move
        if self._stall_override is not None:
            override = self._stall_override
            self._stall_override = None
            # Validate override is still a valid neighbor (graph can change)
            if override in neighbors:
                self._execute_move(override, current_pos, goal_pos)
                return
            # else fall through to normal decision

        self.position_history.append(self.current_node)
        is_cycling, cycle_len = self._detect_cycle()

        if is_cycling:
            self._blacklist_cycle_nodes(cycle_len)
            escape = [n for n in neighbors if n not in self.blacklist]
            if not escape:
                self.blacklist.discard(self.current_node)
                escape = [n for n in neighbors if n not in self.blacklist]
            if not escape:
                escape = neighbors

            # FIX-5: goal-directed escape
            unvisited = [n for n in escape if n not in self.visited]
            pool = unvisited if unvisited else escape
            next_node = self._goal_directed_choice(pool)
            self.oscillation_counter = 0
            self._execute_move(next_node, current_pos, goal_pos)
            return

        # --- Build features ---
        features = self.build_features(neighbors)

        non_bl = [f for f in features if f['blacklist'] < 0.5]
        if not non_bl:
            non_bl = features

        non_taboo = [f for f in non_bl if f['taboo'] < 0.5]
        if not non_taboo:
            best = min(non_bl, key=lambda f: (f['visited'], f['dist']))
            self._taboo_reset()
            self._execute_move(best['node'], current_pos, goal_pos)
            return

        # --- Normal scoring decision ---
        next_node = self.snn.decide(
            neighbor_features=non_bl,
            current_pos=current_pos,
            goal_pos=goal_pos,
            goal_node=self.goal_node
        )

        if next_node is None:
            self.alive = False
            return

        # --- Oscillation counter ---
        if next_node == self.prev_node:
            self.oscillation_counter += 1
            if self.oscillation_counter >= self.OSCILLATION_LIMIT:
                self._blacklist_cycle_nodes(cycle_len=2)
                escape = [n for n in neighbors
                          if n not in self.blacklist and n != self.prev_node]
                if not escape:
                    escape = [n for n in neighbors if n != self.prev_node] or neighbors
                # FIX-5: goal-directed escape
                next_node = self._goal_directed_choice(escape)
                self.oscillation_counter = 0
        else:
            self.oscillation_counter = 0

        # FIX-2: stall measurement removed — lives in _execute_move

        self._execute_move(next_node, current_pos, goal_pos)

    # ------------------------------------------------------------------ #
    # Execute move
    # ------------------------------------------------------------------ #

    def _execute_move(self, next_node, current_pos, goal_pos):
        prev = self.current_node
        self.current_node = next_node
        self.path.append(next_node)

        self.snn.update_momentum(
            current_pos=self.graph._nodes[prev],
            next_pos=self.graph._nodes[next_node]
        )

        self.prev_node = prev
        self.visited.add(next_node)
        self.visit_counts[next_node] = self.visit_counts.get(next_node, 0) + 1
        self._taboo_add(prev)

        nxt_dist = haversine_distance(
            self.graph._nodes[next_node]['lat'],
            self.graph._nodes[next_node]['lon'],
            goal_pos['lat'], goal_pos['lon']
        )

        # FIX-2: stall tracking here — always measures the node actually visited
        if self._last_dist_to_goal is not None:
            if nxt_dist >= self._last_dist_to_goal - 10:
                self._steps_without_progress += 1
            else:
                self._steps_without_progress = 0

            if self._steps_without_progress >= self.MAX_STEPS_WITHOUT_PROGRESS:
                self._taboo_reset()
                self.snn.reset_momentum()
                self._steps_without_progress = 0

                # FIX-3: pick *closest* unvisited neighbor, not farthest
                nbrs = self.get_neighbors()
                all_feats = self.build_features(nbrs)
                non_bl = [f for f in all_feats if f['blacklist'] < 0.5] or all_feats
                unvisited = [
                    f for f in non_bl
                    if f['node'] not in self.visited and f['node'] != self.prev_node
                ]
                if unvisited:
                    self._stall_override = min(unvisited, key=lambda f: f['dist'])['node']
                else:
                    pool = [f for f in non_bl if f['node'] != self.prev_node]
                    self._stall_override = random.choice(pool)['node'] if pool else None

        # Moving-away momentum reset
        if self._last_dist_to_goal is not None and nxt_dist > self._last_dist_to_goal:
            self._moving_away_counter += 1
            if self._moving_away_counter >= 5:
                self.snn.reset_momentum()
                self._moving_away_counter = 0
        else:
            self._moving_away_counter = 0
        self._last_dist_to_goal = nxt_dist

        hazard = self.graph.get_node_damage(next_node)
        if hazard > 0.3:
            self.local_memory["danger_nodes"][next_node] = hazard
        if hazard > 0.9:
            self.alive = False
            return
        if next_node == self.goal_node:
            self.reached_goal = True
            print(f"✓ Agent reached goal! Path length: {len(self.path)}")